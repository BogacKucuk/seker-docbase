export default [
  require('C:\\Users\\bogac\\Desktop\\dev\\seker\\sekerbank-docbase\\node_modules\\infima\\dist\\css\\default\\default.css'),
  require('C:\\Users\\bogac\\Desktop\\dev\\seker\\sekerbank-docbase\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages'),
  require('C:\\Users\\bogac\\Desktop\\dev\\seker\\sekerbank-docbase\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress'),
  require('C:\\Users\\bogac\\Desktop\\dev\\seker\\sekerbank-docbase\\src\\css\\custom.css'),
];
